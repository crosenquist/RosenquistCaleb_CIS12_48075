<html>
  <head>
  </head>
  <body>
    <p>
      <?php
        // Write your if/elseif/else statement here!
        $valid = false;
        if($valid == true){
            echo "The condition is true";
        }else{
            echo "The condition is false";
        }
      ?>
    </p>
  </body>
</html>