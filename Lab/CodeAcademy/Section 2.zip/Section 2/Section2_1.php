<html>
  <head>
    <title>Comparing Numbers</title>
  </head>
  <body>
    <p>
      <?php
            4 < 10;
      ?>
    </p>
  </body>
</html>