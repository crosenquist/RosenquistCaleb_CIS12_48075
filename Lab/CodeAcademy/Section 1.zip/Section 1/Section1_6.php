<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
        <p>
          <?php
            echo "Hello" . "," . " " . "world" . "!";
          ?>
        </p>
	</body>
</html>