<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
        <p>
          <?php
                echo 17 * 123;
          ?>
        </p>
	</body>
</html>