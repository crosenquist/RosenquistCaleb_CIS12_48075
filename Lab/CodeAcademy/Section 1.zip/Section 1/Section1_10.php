<!DOCTYPE html>
<html>
	<head>
		<title>Oh No!</title>
	</head>
	<body>
        <p>
            <?php
                echo "Oh, the humanity!";
                //Don't mind me, I'm just a innocent comment.
            ?>
        </p>
    </body>
</html>