<!DOCTYPE html>
<html>
    <head>
	</head>
	<body>
        <h1>
          <?php
               echo "I'm learning PHP"; 
          ?>
        </h1>
	</body>
</html>