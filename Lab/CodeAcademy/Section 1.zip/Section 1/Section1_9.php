<!DOCTYPE html>
<html>
	<head>
		<title>Oh No!</title>
	</head>
	<body>
        <p><?php
            echo "Oh, the humanity!";
          ?></p>
    </body>
</html>