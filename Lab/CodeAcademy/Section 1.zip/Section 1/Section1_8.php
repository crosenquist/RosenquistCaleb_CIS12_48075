<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
	    <p>
	      <?php
	        $myName = "Caleb";
	      ?>
	    </p>
    </body>
</html>