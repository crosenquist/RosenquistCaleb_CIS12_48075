<!DOCTYPE html>
<html>
    <head>
        <link type='text/css' rel='stylesheet' href='style.css'/>
		<title>PHP FTW!</title>
	</head>
	<body>
        <!-- Write your PHP code below!-->
        <p>
            <?php
                //Variabled
                $myName = "Caleb";
                $myAge  = 22;
                
                //Implementation
                echo $myName;
                echo $myAge;
            ?>
        </p>   
	</body>
</html>