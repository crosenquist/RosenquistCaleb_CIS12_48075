<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
        <p>
          <?php
            echo "I'm learning PHP!";
          ?>
        </p>   
	</body>
</html>